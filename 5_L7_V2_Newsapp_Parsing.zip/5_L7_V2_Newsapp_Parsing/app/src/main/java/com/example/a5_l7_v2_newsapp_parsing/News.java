package com.example.a5_l7_v2_newsapp_parsing;

public class News {

    private String mNameOfTheSection;
    private String mTitle;
    private String mUrl;

    //last two if required
    private String mDate;
    private String mAutor;

/*zakomentowane do sprawdzenia widoku
    public News(String nameOfTheSection, String title, String date, String url, String firstName, String lastName){
        mNameOfTheSection =nameOfTheSection;
        mTitle = title;
        mDate = date;
        mUrl = url;
      mFirstName = firstName;
      mLastName = lastName;

    }
    */

    //second constructor url usuniety do sprawdzenia widoku
    public News(String nameOfTheSection, String title, String date, String url, String autor){
        mNameOfTheSection =nameOfTheSection;
        mTitle = title;
        mDate = date;
        mUrl = url;
        mAutor =autor;
    }

    //gethers methods
    public String getmNameOfTheSection(){return mNameOfTheSection;}

    public String getmTitle(){return mTitle;}

    public String getmDate(){return mDate;}

    public String getmAutor(){return mAutor;}

    public String getmUrl() {return mUrl;}

    // setters

    public void setmNameOfTheSection(String nameOfTheSection){mNameOfTheSection = nameOfTheSection;}

    public void setmTitle(String title){mTitle = title;}

    public void setmDate(String date){mDate = date;}

    public void setmUrl(String url){mUrl = url;}

    public void setmFirstName(String autor){mAutor = autor;}
}