package com.example.a5_l7_v2_newsapp_parsing;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class NewsAdapter extends ArrayAdapter<News> {
    private static final String TIME_SEPARATOR = "T";

    public NewsAdapter(Context context, ArrayList<News> newNews){
        super(context,0,newNews);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        News currentNews = getItem(position);

        TextView curentSection = convertView.findViewById(R.id.nameOfSectionTextV);
        curentSection.setText(currentNews.getmNameOfTheSection());

        TextView currentTitle = convertView.findViewById(R.id.titleTextV);
        currentTitle.setText(currentNews.getmTitle());

        TextView currentDate = convertView.findViewById(R.id.dateTextV);
        if(currentDate != null){
            String fullDate = currentNews.getmDate();
            String date = "";
            String time;
            if (fullDate.contains(TIME_SEPARATOR)){
                String[] parts = fullDate.split(TIME_SEPARATOR);
                date = parts[0];
            }
            currentDate.setText(date);
        }else{
            currentDate.setVisibility(View.GONE);
        }

        TextView currentAutor = convertView.findViewById(R.id.nameTextV);

        if(currentAutor != null){
            currentAutor.setText(currentNews.getmAutor());
        }else {
            currentAutor.setVisibility(View.GONE);
        }

        return convertView;
    }
}

